package com.srienath.restapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
