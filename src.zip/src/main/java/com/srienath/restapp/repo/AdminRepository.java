package com.srienath.restapp.repo;

import com.srienath.restapp.model.Admin;

import java.util.List;
 
public interface AdminRepository {
    Admin add(Admin admin);
    void delete(int adminID);
    Admin update(Admin admin);
    Admin findById(int adminID);
    List<Admin> findAll();
}
