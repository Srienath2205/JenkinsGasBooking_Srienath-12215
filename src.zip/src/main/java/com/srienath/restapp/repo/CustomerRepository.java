package com.srienath.restapp.repo;

import com.srienath.restapp.model.Customer;
import java.util.List;
 
public interface CustomerRepository {
    Customer add(Customer customer);
    void delete(Long customerID);
    Customer update(Customer customer);
    Customer findById(Long customerID);
    List<Customer> findAll();
}
