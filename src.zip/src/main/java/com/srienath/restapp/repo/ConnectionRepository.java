package com.srienath.restapp.repo;

import com.srienath.restapp.model.Connection;
import java.util.List;
 
public interface ConnectionRepository {
    Connection add(Connection connection);
    void delete(Long connectionID);
    Connection update(Connection connection);
    Connection findById(Long connectionID);
    List<Connection> findAll();
}
