package com.srienath.restapp.repo;

import com.srienath.restapp.model.Booking;
import java.util.List;
 
public interface BookingRepository {
    Booking add(Booking booking);
    void delete(Long bookingID);
    Booking update(Booking booking);
    Booking findById(Long bookingID);
    List<Booking> findAll();
}
