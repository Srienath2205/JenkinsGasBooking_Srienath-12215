package com.srienath.restapp.repo;

import com.srienath.restapp.model.DeliveryStaff;
import java.util.List;
 
public interface DeliveryStaffRepository {
    DeliveryStaff add(DeliveryStaff deliveryStaff);
    void delete(Integer staffID);
    DeliveryStaff update(DeliveryStaff deliveryStaff);
    DeliveryStaff findById(Integer staffID);
    List<DeliveryStaff> findAll();
}
