package com.srienath.restapp.service;

import com.srienath.restapp.model.Customer;
import java.util.List;
 
public interface CustomerService {
    Customer addCustomer(Customer customer);
    void deleteCustomer(Long customerID);
    Customer updateCustomer(Customer customer);
    Customer viewCustomer(Long customerID);
    List<Customer> viewAllCustomers();
}
