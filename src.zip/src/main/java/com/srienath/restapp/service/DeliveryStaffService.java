package com.srienath.restapp.service;

import com.srienath.restapp.model.DeliveryStaff;
import java.util.List;
 
public interface DeliveryStaffService {
    DeliveryStaff addDeliveryStaff(DeliveryStaff deliveryStaff);
    void deleteDeliveryStaff(Integer staffID);
    DeliveryStaff updateDeliveryStaff(DeliveryStaff deliveryStaff);
    DeliveryStaff viewDeliveryStaff(Integer staffID);
    List<DeliveryStaff> viewAllDeliveryStaff();
}