package com.srienath.restapp.service;

import com.srienath.restapp.model.Booking;
import java.util.List;
 
public interface BookingService {
    Booking addBooking(Booking booking);
    void deleteBooking(Long bookingID);
    Booking updateBooking(Booking booking);
    Booking viewBooking(Long bookingID);
    List<Booking> viewAllBookings();
}