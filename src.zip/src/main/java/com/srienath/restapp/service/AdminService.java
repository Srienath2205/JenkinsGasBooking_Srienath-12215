package com.srienath.restapp.service;

import com.srienath.restapp.model.Admin;
import java.util.List;
 
public interface AdminService {
    Admin addAdmin(Admin admin);
    void deleteAdmin(int adminID);
    Admin updateAdmin(Admin admin);
    Admin viewAdmin(int adminID);
    List<Admin> viewAllAdmins();
}
