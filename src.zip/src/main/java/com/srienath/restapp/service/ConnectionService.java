package com.srienath.restapp.service;

import com.srienath.restapp.model.Connection;
import java.util.List;
 
public interface ConnectionService {
    Connection addConnection(Connection connection);
    void deleteConnection(Long connectionID);
    Connection updateConnection(Connection connection);
    Connection viewConnection(Long connectionID);
    List<Connection> viewAllConnections();
}