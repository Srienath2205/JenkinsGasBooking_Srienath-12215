package com.srienath.restapp.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;
import com.srienath.restapp.model.Admin;
import com.srienath.restapp.repo.AdminRepository;
import com.srienath.restapp.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	 private final AdminRepository adminRepository;
	 
	 public AdminServiceImpl(AdminRepository adminRepository) {
		 this.adminRepository = adminRepository;
	 }
	 
	 @Override
	 public Admin addAdmin(Admin admin) {
		 return adminRepository.add(admin);
	 }
	 
	 @Override
	 public void deleteAdmin(int adminID) {
		 adminRepository.delete(adminID);
	 }
	 
	 @Override
	 public Admin updateAdmin(Admin admin) {
		 return adminRepository.update(admin);
	 }
	 
	 @Override
	 public Admin viewAdmin(int adminID) {
		 return adminRepository.findById(adminID);
	 }
	 
	 @Override
	 public List<Admin> viewAllAdmins() {
		 return adminRepository.findAll();
	 }

}
