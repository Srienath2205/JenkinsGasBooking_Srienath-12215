package com.srienath.restapp.serviceimpl;

import com.srienath.restapp.model.Customer;
import com.srienath.restapp.repo.CustomerRepository;
import com.srienath.restapp.service.CustomerService;
import org.springframework.stereotype.Service;
import java.util.List;
 
@Service
public class CustomerServiceImpl implements CustomerService {
 
    private final CustomerRepository customerRepository;

    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }
 
    @Override
    public Customer addCustomer(Customer customer) {
        return customerRepository.add(customer);
    }
 
    @Override
    public void deleteCustomer(Long customerID) {
        customerRepository.delete(customerID);
    }
 
    @Override
    public Customer updateCustomer(Customer customer) {
        return customerRepository.update(customer);
    }
 
    @Override
    public Customer viewCustomer(Long customerID) {
        return customerRepository.findById(customerID);
    }
 
    @Override
    public List<Customer> viewAllCustomers() {
        return customerRepository.findAll();
    }
}