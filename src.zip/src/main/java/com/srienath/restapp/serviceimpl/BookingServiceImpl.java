package com.srienath.restapp.serviceimpl;

import java.util.List;
import org.springframework.stereotype.Service;
import com.srienath.restapp.model.Booking;
import com.srienath.restapp.repo.BookingRepository;
import com.srienath.restapp.service.BookingService;

@Service
public class BookingServiceImpl implements BookingService {

	private final BookingRepository bookingRepository;
	
    public BookingServiceImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }
 
    @Override
    public Booking addBooking(Booking booking) {
        return bookingRepository.add(booking);
    }
 
    @Override
    public void deleteBooking(Long bookingID) {
        bookingRepository.delete(bookingID);
    }
 
    @Override
    public Booking updateBooking(Booking booking) {
        return bookingRepository.update(booking);
    }
 
    @Override
    public Booking viewBooking(Long bookingID) {
        return bookingRepository.findById(bookingID);
    }
 
    @Override
    public List<Booking> viewAllBookings() {
        return bookingRepository.findAll();
    }

}
