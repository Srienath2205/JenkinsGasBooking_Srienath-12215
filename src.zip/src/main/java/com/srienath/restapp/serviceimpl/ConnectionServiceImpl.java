package com.srienath.restapp.serviceimpl;

import com.srienath.restapp.model.Connection;
import com.srienath.restapp.repo.ConnectionRepository;
import com.srienath.restapp.service.ConnectionService;
import org.springframework.stereotype.Service;
import java.util.List;
 
@Service
public class ConnectionServiceImpl implements ConnectionService {
 
    private final ConnectionRepository connectionRepository;

    public ConnectionServiceImpl(ConnectionRepository connectionRepository) {
        this.connectionRepository = connectionRepository;
    }
 
    @Override
    public Connection addConnection(Connection connection) {
        return connectionRepository.add(connection);
    }
 
    @Override
    public void deleteConnection(Long connectionID) {
        connectionRepository.delete(connectionID);
    }
 
    @Override
    public Connection updateConnection(Connection connection) {
        return connectionRepository.update(connection);
    }
 
    @Override
    public Connection viewConnection(Long connectionID) {
        return connectionRepository.findById(connectionID);
    }
 
    @Override
    public List<Connection> viewAllConnections() {
        return connectionRepository.findAll();
    }
}