package com.srienath.restapp.serviceimpl;

import com.srienath.restapp.model.DeliveryStaff;
import com.srienath.restapp.repo.DeliveryStaffRepository;
import com.srienath.restapp.service.DeliveryStaffService;
import org.springframework.stereotype.Service;
import java.util.List;
 
@Service
public class DeliveryStaffServiceImpl implements DeliveryStaffService {
 
    private final DeliveryStaffRepository deliveryStaffRepository;
 
    public DeliveryStaffServiceImpl(DeliveryStaffRepository deliveryStaffRepository) {
        this.deliveryStaffRepository = deliveryStaffRepository;
    }
 
    @Override
    public DeliveryStaff addDeliveryStaff(DeliveryStaff deliveryStaff) {
        return deliveryStaffRepository.add(deliveryStaff);
    }
 
    @Override
    public void deleteDeliveryStaff(Integer staffID) {
        deliveryStaffRepository.delete(staffID);
    }
 
    @Override
    public DeliveryStaff updateDeliveryStaff(DeliveryStaff deliveryStaff) {
        return deliveryStaffRepository.update(deliveryStaff);
    }
 
    @Override
    public DeliveryStaff viewDeliveryStaff(Integer staffID) {
        return deliveryStaffRepository.findById(staffID);
    }
 
    @Override
    public List<DeliveryStaff> viewAllDeliveryStaff() {
        return deliveryStaffRepository.findAll();
    }
}
