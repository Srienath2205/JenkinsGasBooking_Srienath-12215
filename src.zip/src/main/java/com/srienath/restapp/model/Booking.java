package com.srienath.restapp.model;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookings")
public class Booking {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingID;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "connectionID")
    private Connection connection;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customerID")
    private Customer customer;
    
    private int cylindersRequired;
    
    private String bookingStatus;
    
    private Date bookingDate;
    
    private Date deliveryDate;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "staffID")
    private DeliveryStaff deliverystaff;
    
    private String paymentMethod;
  
    // Getters and Setters

    public Long getBookingID() {
		return bookingID;
	}

	public void setBookingID(Long bookingID) {
		this.bookingID = bookingID;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getCylindersRequired() {
		return cylindersRequired;
	}

	public void setCylindersRequired(int cylindersRequired) {
		this.cylindersRequired = cylindersRequired;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public DeliveryStaff getDeliverystaff() {
		return deliverystaff;
	}

	public void setDeliverystaff(DeliveryStaff deliverystaff) {
		this.deliverystaff = deliverystaff;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	// Constructors

	public Booking(Long bookingID, Connection connection, Customer customer, int cylindersRequired,
			String bookingStatus, Date bookingDate, Date deliveryDate, DeliveryStaff deliverystaff,
			String paymentMethod) {
		super();
		this.bookingID = bookingID;
		this.connection = connection;
		this.customer = customer;
		this.cylindersRequired = cylindersRequired;
		this.bookingStatus = bookingStatus;
		this.bookingDate = bookingDate;
		this.deliveryDate = deliveryDate;
		this.deliverystaff = deliverystaff;
		this.paymentMethod = paymentMethod;
	}

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
		
}