package com.srienath.restapp.model;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Connection {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long connectionID;
    
    @ManyToOne
    @JoinColumn(name = "customerID")
    private Customer customer;
    
    private String connectionStatus;
    
    private String remarks;
    
    private Date connectionDate;

    // Getters and Setters
    
	public Long getConnectionID() {
		return connectionID;
	}

	public void setConnectionID(Long connectionID) {
		this.connectionID = connectionID;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getConnectionStatus() {
		return connectionStatus;
	}

	public void setConnectionStatus(String connectionStatus) {
		this.connectionStatus = connectionStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getConnectionDate() {
		return connectionDate;
	}

	public void setConnectionDate(Date connectionDate) {
		this.connectionDate = connectionDate;
	}
	
	// Constructors

	public Connection(Long connectionID, Customer customer, String connectionStatus, String remarks,
			Date connectionDate) {
		super();
		this.connectionID = connectionID;
		this.customer = customer;
		this.connectionStatus = connectionStatus;
		this.remarks = remarks;
		this.connectionDate = connectionDate;
	}

	public Connection() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
