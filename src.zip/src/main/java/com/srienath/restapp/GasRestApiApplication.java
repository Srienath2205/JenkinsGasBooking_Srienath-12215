package com.srienath.restapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasRestApiApplication.class, args);
	}

}
