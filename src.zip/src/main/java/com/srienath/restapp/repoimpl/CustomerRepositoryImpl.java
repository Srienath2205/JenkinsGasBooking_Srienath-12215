package com.srienath.restapp.repoimpl;

import com.srienath.restapp.model.Customer;
import com.srienath.restapp.repo.CustomerRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.stereotype.Repository;
 
@Repository
@Transactional
public class CustomerRepositoryImpl implements CustomerRepository {
 
    @PersistenceContext
    private EntityManager entityManager;
 
    @Override
    public Customer add(Customer customer) {
        entityManager.persist(customer);
        return customer;
    }
 
    @Override
    public void delete(Long customerID) {
        Customer customer = entityManager.find(Customer.class, customerID);
        if (customer != null) {
            entityManager.remove(customer);
        }
    }
 
    @Override
    public Customer update(Customer customer) {
        return entityManager.merge(customer);
    }
 
    @Override
    public Customer findById(Long customerID) {
        return entityManager.find(Customer.class, customerID);
    }
 
    @Override
    public List<Customer> findAll() {
        return entityManager.createQuery("FROM Customer", Customer.class).getResultList();
    }
}