package com.srienath.restapp.repoimpl;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.srienath.restapp.model.Booking;
import com.srienath.restapp.repo.BookingRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class BookingRepositoryImpl implements BookingRepository {

	@PersistenceContext
    private EntityManager entityManager;
 
    @Override
    public Booking add(Booking booking) {
        entityManager.persist(booking);
        return booking;
    }
 
    @Override
    public void delete(Long bookingID) {
        Booking booking = entityManager.find(Booking.class, bookingID);
        if (booking != null) {
            entityManager.remove(booking);
        }
    }
 
    @Override
    public Booking update(Booking booking) {
        return entityManager.merge(booking);
    }
 
    @Override
    public Booking findById(Long bookingID) {
        return entityManager.find(Booking.class, bookingID);
    }
 
    @Override
    public List<Booking> findAll() {
        return entityManager.createQuery("FROM Booking", Booking.class).getResultList();
    }

}
