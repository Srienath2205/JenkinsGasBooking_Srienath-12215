package com.srienath.restapp.repoimpl;

import com.srienath.restapp.model.DeliveryStaff;
import com.srienath.restapp.repo.DeliveryStaffRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

import org.springframework.stereotype.Repository;
import java.util.List;
 
@Repository
@Transactional
public class DeliveryStaffRepositoryImpl implements DeliveryStaffRepository {
 
    @PersistenceContext
    private EntityManager entityManager;
 
    @Override
    public DeliveryStaff add(DeliveryStaff deliveryStaff) {
        entityManager.persist(deliveryStaff);
        return deliveryStaff;
    }
 
    @Override
    public void delete(Integer staffID) {
        DeliveryStaff deliveryStaff = entityManager.find(DeliveryStaff.class, staffID);
        if (deliveryStaff != null) {
            entityManager.remove(deliveryStaff);
        }
    }
 
    @Override
    public DeliveryStaff update(DeliveryStaff deliveryStaff) {
        return entityManager.merge(deliveryStaff);
    }
 
    @Override
    public DeliveryStaff findById(Integer staffID) {
        return entityManager.find(DeliveryStaff.class, staffID);
    }
    
    @Override
    public List<DeliveryStaff> findAll() {
        return entityManager.createQuery("FROM DeliveryStaff", DeliveryStaff.class).getResultList();
    }
}