package com.srienath.restapp.repoimpl;

import java.util.List;
import org.springframework.stereotype.Repository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import com.srienath.restapp.model.Admin;
import com.srienath.restapp.repo.AdminRepository;

@Repository
@Transactional
public class AdminRepositoryImpl implements AdminRepository {
	@PersistenceContext
    private EntityManager entityManager;
 
    @Override
    public Admin add(Admin admin) {
        entityManager.persist(admin);
        return admin;
    }
 
    @Override
    public void delete(int adminID) {
        Admin admin = entityManager.find(Admin.class, adminID);
        if (admin != null) {
            entityManager.remove(admin);
        }
    }
 
    @Override
    public Admin update(Admin admin) {
        return entityManager.merge(admin);
    }
 
    @Override
    public Admin findById(int adminID) {
        return entityManager.find(Admin.class, adminID);
    }
 
    @Override
    public List<Admin> findAll() {
        return entityManager.createQuery("FROM Admin", Admin.class).getResultList();
    }
}
