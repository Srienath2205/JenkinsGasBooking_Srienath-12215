package com.srienath.restapp.repoimpl;

import com.srienath.restapp.model.Connection;
import com.srienath.restapp.repo.ConnectionRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;
import java.util.List;
 
@Repository
@Transactional
public class ConnectionRepositoryImpl implements ConnectionRepository {
 
    @PersistenceContext
    private EntityManager entityManager;
 
    @Override
    public Connection add(Connection connection) {
        entityManager.persist(connection);
        return connection;
    }
 
    @Override
    public void delete(Long connectionID) {
        Connection connection = entityManager.find(Connection.class, connectionID);
        if (connection != null) {
            entityManager.remove(connection);
        }
    }
 
    @Override
    public Connection update(Connection connection) {
        return entityManager.merge(connection);
    }
 
    @Override
    public Connection findById(Long connectionID) {
        return entityManager.find(Connection.class, connectionID);
    }
 
    @Override
    public List<Connection> findAll() {
        return entityManager.createQuery("FROM Connection", Connection.class).getResultList();
    }
}