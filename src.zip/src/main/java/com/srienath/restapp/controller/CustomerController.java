package com.srienath.restapp.controller;

import com.srienath.restapp.model.Customer;
import com.srienath.restapp.service.CustomerService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
 
@RestController
@RequestMapping("/customers")
@CrossOrigin("http://localhost:3000")
public class CustomerController {
 
    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }
 
    @PostMapping
    public String addCustomer(@RequestBody Customer customer) {
    	String msg="";
		try {
			customerService.addCustomer(customer);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @DeleteMapping("/{customerID}")
    public String deleteCustomer(@PathVariable Long customerID) {
    	String msg="";
		try {
			customerService.deleteCustomer(customerID);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @PutMapping
    public String updateCustomer(@RequestBody Customer customer) {
    	String msg="";
		try {
			customerService.updateCustomer(customer);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @GetMapping("/{customerID}")
    public Customer viewCustomer(@PathVariable Long customerID) {
		return customerService.viewCustomer(customerID);
    }
 
    @GetMapping
    public List<Customer> viewAllCustomers() {
		return customerService.viewAllCustomers();

    }
}