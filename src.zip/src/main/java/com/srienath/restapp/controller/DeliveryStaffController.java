package com.srienath.restapp.controller;

import com.srienath.restapp.model.DeliveryStaff;
import com.srienath.restapp.service.DeliveryStaffService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
 
@RestController
@RequestMapping("/deliverystaff")
@CrossOrigin("http://localhost:3000")
public class DeliveryStaffController {
 
    private final DeliveryStaffService deliveryStaffService;
 
    public DeliveryStaffController(DeliveryStaffService deliveryStaffService) {
        this.deliveryStaffService = deliveryStaffService;
    }
 
    @PostMapping
    public String addDeliveryStaff(@RequestBody DeliveryStaff deliveryStaff) {
    	String msg="";
		try {
			deliveryStaffService.addDeliveryStaff(deliveryStaff);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @DeleteMapping("/{staffID}")
    public String deleteDeliveryStaff(@PathVariable Integer staffID) {
    	String msg="";
		try {
			deliveryStaffService.deleteDeliveryStaff(staffID);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @PutMapping
    public String updateDeliveryStaff(@RequestBody DeliveryStaff deliveryStaff) {
    	String msg="";
		try {
			deliveryStaffService.updateDeliveryStaff(deliveryStaff);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @GetMapping("/{staffID}")
    public DeliveryStaff viewDeliveryStaff(@PathVariable Integer staffID) {
		return deliveryStaffService.viewDeliveryStaff(staffID);

    }
 
    @GetMapping
    public List<DeliveryStaff> viewAllDeliveryStaff() {
		return deliveryStaffService.viewAllDeliveryStaff();
    }
}
