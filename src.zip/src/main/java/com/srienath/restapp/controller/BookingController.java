package com.srienath.restapp.controller;

import com.srienath.restapp.model.Booking;
import com.srienath.restapp.service.BookingService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
 
@RestController
@RequestMapping("/bookings")
@CrossOrigin("http://localhost:3000")
public class BookingController {
 
    private final BookingService bookingService;
 
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }
 
    @PostMapping
    public String addBooking(@RequestBody Booking booking) {
    	String msg="";
		try {
			bookingService.addBooking(booking);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @DeleteMapping("/{bookingID}")
    public String deleteBooking(@PathVariable Long bookingID) {
    	String msg="";
		try {
			bookingService.deleteBooking(bookingID);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @PutMapping
    public String updateBooking(@RequestBody Booking booking) {
    	String msg="";
		try {
			bookingService.updateBooking(booking);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @GetMapping("/{bookingID}")
    public Booking viewBooking(@PathVariable Long bookingID) {
		return bookingService.viewBooking(bookingID);
    }
 
    @GetMapping
    public List<Booking> viewAllBookings() {
		return bookingService.viewAllBookings();

    }
}