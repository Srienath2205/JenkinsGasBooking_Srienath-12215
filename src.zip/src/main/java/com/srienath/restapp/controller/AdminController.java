package com.srienath.restapp.controller;

import com.srienath.restapp.model.Admin;
import com.srienath.restapp.service.AdminService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
 
@RestController
@RequestMapping("/admin")
@CrossOrigin("http://localhost:3000")
public class AdminController {
 
    private final AdminService adminService;
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }
 
    @PostMapping
    public String addAdmin(@RequestBody Admin admin) {
    	String msg="";
		try {
			adminService.addAdmin(admin);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @DeleteMapping("/{adminID}")
    public String deleteAdmin(@PathVariable int adminID) {
    	String msg="";
		try {
			adminService.deleteAdmin(adminID);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @PutMapping
    public String updateAdmin(@RequestBody Admin admin) {
    	String msg="";
		try {
			adminService.updateAdmin(admin);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @GetMapping("/{adminID}")
    public Admin viewAdmin(@PathVariable int adminID) {
		return adminService.viewAdmin(adminID);

    }
 
    @GetMapping("/all")
    public List<Admin> viewAllAdmins() {
		return adminService.viewAllAdmins();

    }
}
