package com.srienath.restapp.controller;

import com.srienath.restapp.model.Connection;
import com.srienath.restapp.service.ConnectionService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
 
@RestController
@RequestMapping("/connections")
@CrossOrigin("http://localhost:3000")
public class ConnectionController {
 
    private final ConnectionService connectionService;
 
    public ConnectionController(ConnectionService connectionService) {
        this.connectionService = connectionService;
    }
 
    @PostMapping
    public String addConnection(@RequestBody Connection connection) {
    	String msg="";
		try {
			connectionService.addConnection(connection);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @DeleteMapping("/{connectionID}")
    public String deleteConnection(@PathVariable Long connectionID) {
    	String msg="";
		try {
			connectionService.deleteConnection(connectionID);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @PutMapping
    public String updateConnection(@RequestBody Connection connection) {
    	String msg="";
		try {
			connectionService.updateConnection(connection);
			msg="Success";
		} 
		
		catch(Exception e) {
			e.printStackTrace();
			msg="Failure";
		}
		return msg;
    }
 
    @GetMapping("/{connectionID}")
    public Connection viewConnection(@PathVariable Long connectionID) {
		return connectionService.viewConnection(connectionID);

    }
 
    @GetMapping
    public List<Connection> viewAllConnections() {
		return connectionService.viewAllConnections();
    }
}